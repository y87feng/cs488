#pragma once

#define ENABLE_ANTI_ALIASING 0