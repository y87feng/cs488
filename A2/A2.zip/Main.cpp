// Winter 2019

#include "A2.hpp"

int main( int argc, char **argv ) 
{
	CS488Window::launch( argc, argv, new A2(), 768, 768, "** Assignment 2" );
	return 0;
}
